/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;

public class TestService2 {

    @Autowired
    OpenTelemetry openTelemetry;

    public void doLog() {

        try {

            final Meter meter =
                openTelemetry.meterBuilder("instrumentation-library-name").setInstrumentationVersion("1.0.0").build();
            meter.gaugeBuilder("cpu_usage").setDescription("CPU Usage").setUnit("ms").buildWithCallback(measurement -> {
                measurement.record(getCpuUsage(), Attributes.of(AttributeKey.stringKey("key"), "value"));
            });

            final Tracer tracer = openTelemetry.getTracer("com.tomtom.orbis.sourceprocessingutility", "1.0.0");

            final Span rootSpan = tracer.spanBuilder("test-span").startSpan();

            // Make the span the current span
            try (Scope ss = rootSpan.makeCurrent()) {
                final LocalDateTime dateTime = LocalDateTime.now();
                final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyy HH:mm:ss");
                final String formattedString = dateTime.format(formatter);
                rootSpan.setAttribute("featureCount", "500");
                rootSpan.setAttribute("fallOuts", "200");
                rootSpan.setAttribute("stage", "upload");
                rootSpan.setAttribute("formattedString", formattedString);

                addTwoNumber(4, 6, tracer);

            } finally {
                rootSpan.end();
            }

        } catch (final Throwable t) {
            t.printStackTrace();
        }

    }

    private double getCpuUsage() {
        // TODO Auto-generated method stub
        return 10;
    }

    public static void addTwoNumber(final int a, final int b, final Tracer tracer) {
        final Span childSpan = tracer.spanBuilder("child").startSpan();
        try (Scope scope = childSpan.makeCurrent()) {
            final LocalDateTime dateTime = LocalDateTime.now();
            final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyy HH:mm:ss");
            final String formattedString = dateTime.format(formatter);
            childSpan.setAttribute("featureCount", "500");
            childSpan.setAttribute("fallOuts", "200");
            childSpan.setAttribute("stage", "upload");
            childSpan.setAttribute("formattedString", formattedString);
            childSpan.setAttribute("result", a + b);
        } finally {
            childSpan.end();
        }
    }
}
