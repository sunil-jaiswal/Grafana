/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.controller;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;

//@RestController
public class Controller2 {

    // Logger (note that this is not an OTel component)
    private static final org.apache.logging.log4j.Logger LOGGER = LogManager.getLogger(Controller.class);

    // Attribute constants
    private static final AttributeKey<Long> ATTR_N = AttributeKey.longKey("fibonacci.n");
    private static final AttributeKey<Long> ATTR_RESULT = AttributeKey.longKey("fibonacci.result");
    private static final AttributeKey<Boolean> ATTR_VALID_N = AttributeKey.booleanKey("fibonacci.valid.n");

    private final Tracer tracer;
    private final LongCounter fibonacciInvocations;

    @Autowired
    Controller2(final OpenTelemetry openTelemetry) {
        // Initialize tracer
        tracer = openTelemetry.getTracer(Controller.class.getName());
        // Initialize instrument
        final Meter meter = openTelemetry.getMeter(Controller.class.getName());
        fibonacciInvocations = meter.counterBuilder("fibonacci.invocations")
            .setDescription("Measures the number of times the fibonacci method is invoked.").build();
    }

    @GetMapping(value = "fib/{id}")
    public long doLog(@PathVariable final int id) {

        return fibonacci(id);
    }
    private long fibonacci(final long n) {
        // Start a new span and set your first attribute
        final Span span = tracer.spanBuilder("fibonacci").setAttribute(ATTR_N, n).startSpan();

        // Set the span as the current span
        try (Scope scope = span.makeCurrent()) {
            if (n < 1 || n > 90) {
                throw new IllegalArgumentException("n must be 1 <= n <= 90.");
            }

            long result = 1;
            if (n > 2) {
                long a = 0;
                long b = 1;

                for (long i = 1; i < n; i++) {
                    result = a + b;
                    a = b;
                    b = result;
                }
            }
            // Set a span attribute to capture information about successful requests
            span.setAttribute(ATTR_RESULT, result);
            // Counter to increment the number of times a valid input is recorded
            fibonacciInvocations.add(1, Attributes.of(ATTR_VALID_N, true));
            // Log the result of a valid input
            LOGGER.info("Compute fibonacci(" + n + ") = " + result);
            return result;
        } catch (final IllegalArgumentException e) {
            span.recordException(e).setStatus(StatusCode.ERROR, e.getMessage());
            throw e;
        } finally {
            // End the span
            span.end();
        }

    }
}
