/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.controller;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;

//@RestController
public class Controller {


    private final Tracer tracer = GlobalOpenTelemetry.getTracer("io.opentelemetry.traces.hello", "1.0.2");

    private final Meter meter1 =
        GlobalOpenTelemetry.meterBuilder("io.opentelemetry.metrics.hello").setInstrumentationVersion("2.0.1").build();

    private LongCounter numberOfExecutions;

    @PostConstruct
    public void createMetrics() {

        numberOfExecutions =
            meter1.counterBuilder("NUMBER_OF_EXEC_NAME").setDescription("NUMBER_OF_EXEC_DESCRIPTION").setUnit("int").build();

        /*
         * meter1.gaugeBuilder("HEAP_MEMORY_NAME").setDescription("HEAP_MEMORY_DESCRIPTION").setUnit("byte")
         * .buildWithCallback(r -> { r.record(getRuntime().totalMemory() - getRuntime().freeMemory()); });
         */

    }

    @RequestMapping(method = RequestMethod.GET, value = "/hello")
    public String hello() {
        // Creating a custom span
        final Span span = tracer.spanBuilder("mySpan").startSpan();
        try (Scope scope = span.makeCurrent()) {
            System.out.print("The response is valid.");
            // Update the synchronous metric
            numberOfExecutions.add(1);
        } finally {
            span.end();
        }
        return "Success";
    }

    @GetMapping(value = "test")
    public String doLog() {

        /*
         * final Attributes attributes = Attributes.of(AttributeKey.stringKey("my-key-1"), "my-value-1",
         * AttributeKey.stringKey("my-key-2"), Long.valueOf(new Random().nextInt(3)).toString()); counter.add(new
         * Random().nextInt(11), attributes);
         */
        // testService.doLog();

        return "Hello World!!!";
    }
}
