/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.function.Supplier;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tomtom.orbis.sourceprocessingutility.service.TestService;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;

@RestController
public class Controller3 {


    @Autowired
    OpenTelemetry openTelemetry;

    @Autowired
    TestService testService;

    @Autowired
    MeterRegistry meterRegistry;

    private LongCounter numberOfExecutions;
    private Tracer tracer;

    @PostConstruct
    public void createMetrics() {

        final Meter meter =
            openTelemetry.meterBuilder("instrumentation-library-name").setInstrumentationVersion("1.0.0").build();

        tracer = openTelemetry.getTracer("com.tomtom.orbis.sourceprocessingutility", "1.0.0");

        numberOfExecutions =
            meter.counterBuilder("NUMBER_OF_EXEC_NAME").setDescription("NUMBER_OF_EXEC_DESCRIPTION").setUnit("int").build();

        /*
         * meter1.gaugeBuilder("HEAP_MEMORY_NAME").setDescription("HEAP_MEMORY_DESCRIPTION").setUnit("byte")
         * .buildWithCallback(r -> { r.record(getRuntime().totalMemory() - getRuntime().freeMemory()); });
         */

    }

    public Supplier<Number> fetchUserCount() {
        final int val = new Random().nextInt(1000);
        System.out.println("************************************ " + val);
        return () -> val;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/hello")
    public String hello() throws InterruptedException {
        // Creating a custom span
        final Span span = tracer.spanBuilder("test-span").startSpan();
        try (Scope scope = span.makeCurrent()) {

            final Span childSpan = tracer.spanBuilder("child").startSpan();
            try (Scope scope1 = childSpan.makeCurrent()) {
                Thread.sleep(1000);
                final LocalDateTime dateTime = LocalDateTime.now();
                final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyy HH:mm:ss");
                final String formattedString = dateTime.format(formatter);
                childSpan.setAttribute("featureCount", "500");
                childSpan.setAttribute("fallOuts", "200");
                childSpan.setAttribute("stage", "upload");
                childSpan.setAttribute("formattedString", formattedString);
            } finally {
                childSpan.end();
            }

            Gauge.builder("falloutCount", fetchUserCount()).tag("version", "v1")
                .description("Fallout counts during the process").register(meterRegistry);
            Gauge.builder("testCount", fetchUserCount()).tag("version", "v2").description("test registry")
                .register(meterRegistry);

        } finally {
            span.end();
        }
        return "Success";
    }

    @RequestMapping(method = RequestMethod.GET, value = "/_hello")
    public String _hello() {
        // Creating a custom span
        final Span span = tracer.spanBuilder("test-span").startSpan();
        try (Scope scope = span.makeCurrent()) {
            // Update the synchronous metric
            final Attributes attributes = Attributes.of(AttributeKey.stringKey("stage"), "upload",
                AttributeKey.stringKey("fallOuts"), Long.valueOf(new Random().nextInt(3000)).toString());
            numberOfExecutions.add(30000l, attributes);

            Gauge.builder("usercontroller.usercount", fetchUserCount()).tag("version", "v1")
                .description("usercontroller descrip").register(meterRegistry);
            Gauge.builder("test", fetchUserCount()).tag("version", "v2").description("test registry")
                .register(meterRegistry);

        } finally {
            span.end();
        }
        return "Success";
    }

    @GetMapping(value = "test")
    public String doLog() {

        /*
         * final Attributes attributes = Attributes.of(AttributeKey.stringKey("my-key-1"), "my-value-1",
         * AttributeKey.stringKey("my-key-2"), Long.valueOf(new Random().nextInt(3)).toString()); numberOfExecutions.add(new
         * Random().nextInt(11), attributes);
         */
        // testService.doLog();

        return "Hello World!!!";
    }
}
