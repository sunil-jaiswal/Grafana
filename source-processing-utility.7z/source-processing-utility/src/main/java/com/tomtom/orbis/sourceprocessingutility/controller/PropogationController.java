/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.controller;

import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;
import io.opentelemetry.context.propagation.TextMapPropagator;
import io.opentelemetry.context.propagation.TextMapSetter;

@RestController
public class PropogationController {

    @Autowired
    OpenTelemetry openTelemetry;

    public void getUserBillingAddress() {
        final Tracer tracer = openTelemetry.getTracer("cloud.events.second");

        final Span child = tracer.spanBuilder("user-billing-address-service").setSpanKind(SpanKind.CLIENT).startSpan();
        child.addEvent("User billing address with id-service", Instant.EPOCH);
        child.setAttribute("TRACE_ID", child.getSpanContext().getTraceId());
        // MDC.put(TRACE_ID,child.getSpanContext().getTraceId());

        System.out.println("User billing address with id: {}");
        try (Scope scope = child.makeCurrent()) {

            final TextMapSetter<HttpURLConnection> setter = new TextMapSetter<HttpURLConnection>() {

                @Override
                public void set(final HttpURLConnection carrier, final String key, final String value) {
                    carrier.setRequestProperty(key, value);
                }
            };
            final URL url = new URL("http://localhost:8081/address");
            final TextMapPropagator textMapPropagator = W3CTraceContextPropagator.getInstance();
            final HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
            textMapPropagator.inject(Context.current(), httpURLConnection, setter);

        } catch (final Exception exception) {
            exception.printStackTrace();
            System.out.println("Address Service is down");
        } finally {
            child.end();
        }
    }

    @GetMapping(value = "/second1")
    public void doso() {
        getUserBillingAddress();
    }

    @GetMapping(value = "/second")
    public String sencondTest(@RequestHeader(value = "traceparent") final String traceparent) {
        try {
            getUserBillingAddress();
            final Tracer tracer = openTelemetry.getTracer("cloud.events.second");

            final TextMapGetter<ExtractModel> getter = new TextMapGetter<ExtractModel>() {

                @Override
                public String get(final ExtractModel carrier, final String key) {
                    if (carrier.getHeaders().containsKey(key)) {
                        return carrier.getHeaders().get(key);
                    }
                    return null;
                }

                @Override
                public Iterable<String> keys(final ExtractModel carrier) {
                    return carrier.getHeaders().keySet();
                }
            };

            final ExtractModel model = new ExtractModel();
            model.addHeader("traceparent", traceparent);
            final Context extractedContext =
                openTelemetry.getPropagators().getTextMapPropagator().extract(Context.current(), model, getter);

            try (Scope scope = extractedContext.makeCurrent()) {
                // Automatically use the extracted SpanContext as parent.
                final Span serverSpan = tracer.spanBuilder("CloudEvents Server").setSpanKind(SpanKind.SERVER).startSpan();
                try {

                    Thread.sleep(150);
                } finally {
                    serverSpan.end();
                }
            }

        } catch (final InterruptedException e) {
            throw new RuntimeException(e);
        }

        return "Server Received!";
    }
}
