/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.controller;

import org.springframework.beans.factory.annotation.Autowired;

import io.opentelemetry.api.OpenTelemetry;

public class Main {

    @Autowired
    OpenTelemetry openTelemetry;

    public static void main(final String[] args) {

    }

    public void client() {
    }
}
