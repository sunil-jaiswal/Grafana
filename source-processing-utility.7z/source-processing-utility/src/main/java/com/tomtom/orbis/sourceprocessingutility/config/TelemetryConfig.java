/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.tomtom.orbis.sourceprocessingutility.config;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.propagation.ContextPropagators;
import io.opentelemetry.exporter.logging.LoggingMetricExporter;
import io.opentelemetry.exporter.otlp.trace.OtlpGrpcSpanExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.export.PeriodicMetricReader;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.BatchSpanProcessor;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import io.opentelemetry.semconv.resource.attributes.ResourceAttributes;

@Configuration
public class TelemetryConfig {

    @Bean
    public OpenTelemetry getTelemetry() {

        /*
         * final SpanExporter spanExporter =
         * OtlpGrpcSpanExporter.builder().setEndpoint("http://localhost:5555").setTimeout(30, TimeUnit.SECONDS).build();
         */

        final SpanExporter spanExporter =
            OtlpGrpcSpanExporter.builder().setEndpoint("http://localhost:4317").setTimeout(30, TimeUnit.SECONDS).build();


        final Resource resource =
            Resource.getDefault().merge(Resource.create(Attributes.of(ResourceAttributes.SERVICE_NAME, "test-service")));

        final SdkTracerProvider sdkTracerProvider = SdkTracerProvider.builder()
            .addSpanProcessor(BatchSpanProcessor.builder(spanExporter).build()).setResource(resource).build();


        // final MetricExporter metricExporter =
        // OtlpGrpcMetricExporter.builder().setEndpoint("http://localhost:4317").build();

        /*
         * final MetricExporter metricExporter = OtlpHttpMetricExporter.builder()
         * .setEndpoint("https://prometheus-us-central2.grafana.net/api/prom/push") .addHeader("Content-Type",
         * "application/x-protobuf").addHeader("username", "737681") .addHeader("password",
         * "eyJrIjoiYzgyYmJiYjhiMmRiYzViNmVlYzFiYzQ4MzlkZTUxMDVmNjU1NzdhMCIsIm4iOiJwcm9tX2tleSIsImlkIjo3Nzk3MTV9")
         * .addHeader("Authorization",
         * "Basic eyJrIjoiYzgyYmJiYjhiMmRiYzViNmVlYzFiYzQ4MzlkZTUxMDVmNjU1NzdhMCIsIm4iOiJwcm9tX2tleSIsImlkIjo3Nzk3MTV9")
         * .build();
         */

        /*
         * final SdkMeterProvider sdkMeterProvider =
         * SdkMeterProvider.builder().registerMetricReader(PeriodicMetricReader.builder(metricExporter).build()).build();
         */
        /*
         * final SdkMeterProvider sdkMeterProvider = SdkMeterProvider.builder()
         * .registerMetricReader(PeriodicMetricReader.builder(OtlpGrpcMetricExporter.builder()
         * .setEndpoint("http://localhost:4317").setTimeout(30, TimeUnit.SECONDS).build()).build())
         * .setResource(resource).build();
         */
        /*
         * final SdkMeterProvider sdkMeterProvider = SdkMeterProvider.builder() .registerMetricReader(
         * PeriodicMetricReader.builder(LoggingMetricExporter.create()).setInterval(Duration.ofMillis(800l)).build())
         * .setResource(resource).build();
         */

        final SdkMeterProvider sdkMeterProvider = SdkMeterProvider.builder()
            .registerMetricReader(
                PeriodicMetricReader.builder(LoggingMetricExporter.create()).setInterval(Duration.ofMillis(800l)).build())
            .setResource(resource).build();

        Runtime.getRuntime().addShutdownHook(new Thread(sdkTracerProvider::shutdown));

        return OpenTelemetrySdk.builder().setTracerProvider(sdkTracerProvider).setMeterProvider(sdkMeterProvider)
            .setPropagators(ContextPropagators.create(W3CTraceContextPropagator.getInstance())).buildAndRegisterGlobal();
    }

    @Bean
    public CommonsRequestLoggingFilter logFilter() {
        final CommonsRequestLoggingFilter filter = new CommonsRequestLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludeHeaders(true);
        filter.setIncludeClientInfo(true);
        return filter;
    }

    @Bean
    public Meter getMeter() {
        final OpenTelemetry openTelemetry = getTelemetry();
        final Meter meter =
            openTelemetry.meterBuilder("instrumentation-library-name").setInstrumentationVersion("1.0.0").build();
        return meter;
    }

    @Bean
    public LongCounter getLongCounter() {
        final Meter meter = getMeter();
        return meter.counterBuilder("my-counter").setDescription("This is my cool counter.").build();
    }

}
